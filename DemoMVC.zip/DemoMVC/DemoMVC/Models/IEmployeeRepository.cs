﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoMVC.Models
{
    public interface IEmployeeRepository
    {
        public List<Employee> ViewEmployee();
        int AddEmployee(Employee employee);
        Employee GetEmployee(int Id);
    }
}
