﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DemoMVC.Models
{
    public class Employee
    {
        [Display(Name = "Employee ID")]
        [Key]
        public int ID { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [MaxLength(10)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Date of Joining is required")]
        public DateTime DOJ { get; set; }

        [Required(ErrorMessage = "Department ID is required")]
        public int DepartmentID { get; set; }
    }
}
