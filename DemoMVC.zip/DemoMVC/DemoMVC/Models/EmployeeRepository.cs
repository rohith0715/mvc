﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoMVC.Models
{
    public class EmployeeRepository:IEmployeeRepository
    {
        EmployeeContext _context;
        public EmployeeRepository(EmployeeContext context)
        {
            _context = context;
        }

        public List<Employee> ViewEmployee()
        {
            return _context.Employee.ToList();
        }
        public int AddEmployee(Employee employee)
        {
            _context.Employee.Add(employee);
            _context.SaveChanges();
            return employee.ID;
        }

        public Employee GetEmployee(int Id)
        {
            return _context.Employee.Find(Id);
            //return _context.Employee.Where{ a->a.ID == Id).FirstOrDefault;
        }
    }
}
